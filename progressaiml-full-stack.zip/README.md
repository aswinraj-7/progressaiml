# ProgressAI ML — Full-stack Student Performance Predictor

## What is included
- `backend/`: Flask API + trained Random Forest model + reproducible training script + dataset.
- `frontend/index.html`: Netlify-ready website that calls the API.

## 1. Deploy backend on Render
1. Create a GitHub repository and upload the `backend` folder contents.
2. On Render, create a **Web Service** connected to that repository.
3. Build command: `pip install -r requirements.txt`
4. Start command: `gunicorn app:app`
5. Deploy and copy the generated `https://...onrender.com` URL.

## 2. Connect Netlify
Open `frontend/index.html` and replace:
`https://YOUR-BACKEND-URL.onrender.com`
with your actual Render URL.

Then redeploy `frontend/index.html` to your existing Netlify site.

## 3. API
GET `/` -> health/status.
POST `/predict` accepts:
{
  "study_hours": 4,
  "attendance": 82,
  "previous_score": 76,
  "assignments": 85,
  "sleep_hours": 7,
  "engagement": 2
}

The response contains `prediction`, `status`, `risk`, `grade`, `confidence`, and `model`.

## Local test
Backend:
`pip install -r requirements.txt`
`python train_model.py`
`python app.py`

Frontend can be opened with a local server after changing API_URL to `http://127.0.0.1:5000`.
